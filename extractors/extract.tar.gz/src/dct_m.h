/**
 *  Copyright (c) DDE Lab, SUNY Binghamton, 2007-2008
 *  Written by Jan Kodovsky, e-mail: jan@kodovsky.com
 *
 *  @author Jan Kodovsky
 */

#ifndef MATLABDCT_H
#define MATLABDCT_H
void jpeg_fdct_islow_matlab (double out[], double in[]);

#endif
