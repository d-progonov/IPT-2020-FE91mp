/**
 *  Copyright (c) DDE Lab, SUNY Binghamton, 2007-2008
 *  Written by Jan Kodovsky, e-mail: jan@kodovsky.com
 *
 *  @author Jan Kodovsky
 */
#ifndef MATLABIDCT_H
#define MATLABIDCT_H

void jpeg_idct_islow_matlab (double out[], double coef_block[], double qt[]);

#endif
